-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 15, 2024 at 09:24 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projekandi`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_hotel`
--

CREATE TABLE `data_hotel` (
  `id_hotel` int NOT NULL,
  `nama_hotel` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `kota` enum('Badung','Denpasar','Gianyar','Karang Asem','Buleleng','Jembrana') COLLATE utf8mb4_general_ci NOT NULL,
  `jenis_kamar` enum('Standart','Deluxe','Suite') COLLATE utf8mb4_general_ci NOT NULL,
  `harga` int NOT NULL,
  `jumlah_kamar_tersedia` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `data_hotel`
--

INSERT INTO `data_hotel` (`id_hotel`, `nama_hotel`, `kota`, `jenis_kamar`, `harga`, `jumlah_kamar_tersedia`) VALUES
(1, 'Hotel Bali Paradise', 'Badung', 'Standart', 500000, 10),
(2, 'Hotel Bali Paradise', 'Badung', 'Deluxe', 750000, 10),
(3, 'Hotel Bali Paradise', 'Badung', 'Suite', 1000000, 10),
(4, 'Denpasar Beach Hotel', 'Denpasar', 'Standart', 400000, 10),
(5, 'Denpasar Beach Hotel', 'Denpasar', 'Deluxe', 650000, 10),
(6, 'Denpasar Beach Hotel', 'Denpasar', 'Suite', 900000, 10),
(7, 'Gianyar Resort', 'Gianyar', 'Standart', 450000, 10),
(8, 'Gianyar Resort', 'Gianyar', 'Deluxe', 700000, 10),
(9, 'Gianyar Resort', 'Gianyar', 'Suite', 950000, 10),
(10, 'Karang Asem Lodge', 'Karang Asem', 'Standart', 480000, 10),
(11, 'Karang Asem Lodge', 'Karang Asem', 'Deluxe', 730000, 10),
(12, 'Karang Asem Lodge', 'Karang Asem', 'Suite', 980000, 10),
(13, 'Buleleng Sunset Inn', 'Buleleng', 'Standart', 420000, 10),
(14, 'Buleleng Sunset Inn', 'Buleleng', 'Deluxe', 670000, 10),
(15, 'Buleleng Sunset Inn', 'Buleleng', 'Suite', 920000, 10),
(16, 'Jembrana Ocean Hotel', 'Jembrana', 'Standart', 450000, 10),
(17, 'Jembrana Ocean Hotel', 'Jembrana', 'Deluxe', 700000, 10),
(18, 'Jembrana Ocean Hotel', 'Jembrana', 'Suite', 950000, 10),
(19, 'Beachside Retreat', 'Badung', 'Standart', 520000, 10),
(20, 'Beachside Retreat', 'Badung', 'Deluxe', 770000, 10),
(21, 'Beachside Retreat', 'Badung', 'Suite', 1020000, 10),
(22, 'Denpasar Central Hotel', 'Denpasar', 'Standart', 410000, 10),
(23, 'Denpasar Central Hotel', 'Denpasar', 'Deluxe', 660000, 10),
(24, 'Denpasar Central Hotel', 'Denpasar', 'Suite', 910000, 10),
(25, 'Ubud Serenity', 'Gianyar', 'Standart', 460000, 10),
(26, 'Ubud Serenity', 'Gianyar', 'Deluxe', 710000, 10),
(27, 'Ubud Serenity', 'Gianyar', 'Suite', 960000, 10),
(28, 'Villa Amed', 'Karang Asem', 'Standart', 490000, 10),
(29, 'Villa Amed', 'Karang Asem', 'Deluxe', 740000, 10),
(30, 'Villa Amed', 'Karang Asem', 'Suite', 990000, 10),
(31, 'Lovina Seaview', 'Buleleng', 'Standart', 430000, 10),
(32, 'Lovina Seaview', 'Buleleng', 'Deluxe', 680000, 10),
(33, 'Lovina Seaview', 'Buleleng', 'Suite', 930000, 10),
(34, 'West Bali Villas', 'Jembrana', 'Standart', 460000, 10),
(35, 'West Bali Villas', 'Jembrana', 'Deluxe', 710000, 10),
(36, 'West Bali Villas', 'Jembrana', 'Suite', 960000, 10);

-- --------------------------------------------------------

--
-- Table structure for table `data_wisata`
--

CREATE TABLE `data_wisata` (
  `id_wisata` int NOT NULL,
  `nama_wisata` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `kota` enum('Badung','Denpasar','Gianyar','Karang Asem','Buleleng','Jembrana') COLLATE utf8mb4_general_ci NOT NULL,
  `harga` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `data_wisata`
--

INSERT INTO `data_wisata` (`id_wisata`, `nama_wisata`, `kota`, `harga`) VALUES
(1, 'Pantai Kuta', 'Badung', 100000),
(2, 'Pura Uluwatu', 'Badung', 75000),
(3, 'Pantai Pandawa', 'Badung', 80000),
(4, 'Museum Bali', 'Denpasar', 50000),
(5, 'Taman Budaya Art Centre', 'Denpasar', 60000),
(6, 'Bajra Sandhi Monument', 'Denpasar', 70000),
(7, 'Ubud Monkey Forest', 'Gianyar', 85000),
(8, 'Goa Gajah', 'Gianyar', 90000),
(9, 'Tegallalang Rice Terrace', 'Gianyar', 80000),
(10, 'Taman Ujung Water Palace', 'Karang Asem', 75000),
(11, 'Pura Lempuyang', 'Karang Asem', 95000),
(12, 'Amed Beach', 'Karang Asem', 65000),
(13, 'Lovina Beach', 'Buleleng', 70000),
(14, 'Gitgit Waterfall', 'Buleleng', 80000),
(15, 'Banjar Hot Springs', 'Buleleng', 85000),
(16, 'Pantai Medewi', 'Jembrana', 60000),
(17, 'Pulaki Temple', 'Jembrana', 50000),
(18, 'Bunut Bolong', 'Jembrana', 55000),
(19, 'Canggu Beach', 'Badung', 95000),
(20, 'Seminyak Beach', 'Badung', 85000),
(21, 'Sanur Beach', 'Denpasar', 65000),
(22, 'Puri Saren Ubud', 'Gianyar', 70000),
(23, 'Mount Agung', 'Karang Asem', 100000),
(24, 'Sekumpul Waterfall', 'Buleleng', 90000),
(25, 'Jembrana Cultural Village', 'Jembrana', 40000),
(26, 'Dreamland Beach', 'Badung', 95000),
(27, 'Garuda Wisnu Kencana', 'Badung', 125000),
(28, 'Pantai Jimbaran', 'Badung', 50000),
(29, 'Waterbom Bali', 'Badung', 200000),
(30, 'Pantai Petitenget', 'Badung', 45000),
(31, 'Bali Bird Park', 'Gianyar', 150000),
(32, 'Bali Safari and Marine Park', 'Gianyar', 250000),
(33, 'Campuhan Ridge Walk', 'Gianyar', 60000),
(34, 'Goa Rang Reng Waterfall', 'Gianyar', 70000),
(35, 'Tirta Empul Temple', 'Gianyar', 90000),
(36, 'Blue Lagoon Beach', 'Karang Asem', 75000),
(37, 'Taman Tirta Gangga', 'Karang Asem', 80000),
(38, 'White Sand Beach', 'Karang Asem', 70000),
(39, 'Tulamben Diving Site', 'Karang Asem', 150000),
(40, 'Pura Besakih', 'Karang Asem', 100000),
(41, 'Aling-Aling Waterfall', 'Buleleng', 85000),
(42, 'Pura Beji', 'Buleleng', 50000),
(43, 'Krisna Funtastic Land', 'Buleleng', 120000),
(44, 'Wanagiri Hidden Hills', 'Buleleng', 100000),
(45, 'Menjangan Island', 'Buleleng', 140000),
(46, 'Perancak Beach', 'Jembrana', 60000),
(47, 'Makepung Buffalo Races', 'Jembrana', 70000),
(48, 'Pengambengan Fishing Village', 'Jembrana', 55000),
(49, 'Palasari Dam', 'Jembrana', 65000),
(50, 'Candikusuma Beach', 'Jembrana', 50000),
(51, 'Kelingking Beach', 'Badung', 120000),
(52, 'Broken Beach', 'Badung', 100000),
(53, 'Angel Billabong', 'Badung', 100000),
(54, 'Munduk Waterfall', 'Buleleng', 85000),
(55, 'Handara Gate', 'Buleleng', 60000),
(56, 'Pantai Nyang-Nyang', 'Badung', 75000),
(57, 'Padang Padang Beach', 'Badung', 85000),
(58, 'Ujung Water Palace', 'Karang Asem', 70000),
(59, 'Pantai Melasti', 'Badung', 65000),
(60, 'Pandawa Marine Adventures', 'Badung', 180000),
(61, 'Surf & Turf Nusa Dua', 'Badung', 250000),
(62, 'Pura Gunung Kawi', 'Gianyar', 80000),
(63, 'Nusa Dua Beach', 'Badung', 90000),
(64, 'Secret Garden Village', 'Buleleng', 110000),
(65, 'Lovina Dolphin Watching', 'Buleleng', 130000),
(66, 'Desa Tenganan Pegringsingan', 'Karang Asem', 50000),
(67, 'Pantai Virgin', 'Karang Asem', 60000);

-- --------------------------------------------------------

--
-- Table structure for table `detail_tiket_hotel`
--

CREATE TABLE `detail_tiket_hotel` (
  `id_DTH` int NOT NULL,
  `id_tiket_hotel` int NOT NULL,
  `id_hotel` int NOT NULL,
  `jumlah_kamar` int NOT NULL,
  `total_harga` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_tiket_hotel`
--

INSERT INTO `detail_tiket_hotel` (`id_DTH`, `id_tiket_hotel`, `id_hotel`, `jumlah_kamar`, `total_harga`) VALUES
(1, 3, 20, 1, 770000),
(2, 3, 21, 1, 1020000),
(5, 5, 20, 1, 770000),
(6, 5, 21, 1, 1020000),
(7, 6, 20, 1, 770000),
(8, 6, 21, 1, 1020000),
(9, 7, 20, 1, 770000),
(10, 7, 21, 1, 1020000),
(11, 8, 20, 3, 2310000),
(12, 8, 21, 2, 2040000),
(13, 9, 20, 2, 1540000),
(14, 9, 21, 2, 2040000),
(18, 10, 4, 2, 800000),
(19, 10, 6, 2, 1800000),
(22, 11, 22, 1, 410000),
(23, 11, 23, 1, 660000),
(24, 11, 24, 1, 910000),
(25, 12, 34, 1, 460000),
(26, 13, 28, 3, 1470000),
(27, 13, 29, 1, 740000),
(28, 13, 30, 1, 990000),
(29, 14, 28, 1, 490000);

-- --------------------------------------------------------

--
-- Table structure for table `tarif_rute`
--

CREATE TABLE `tarif_rute` (
  `id_tarif` int NOT NULL,
  `tempat_asal` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `tempat_tujuan` enum('Badung','Denpasar','Gianyar','Karang Asem','Buleleng','Jembrana') COLLATE utf8mb4_general_ci NOT NULL,
  `jenis_kendaraan` enum('Pesawat','Bis','Kapal') COLLATE utf8mb4_general_ci NOT NULL,
  `harga` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tarif_rute`
--

INSERT INTO `tarif_rute` (`id_tarif`, `tempat_asal`, `tempat_tujuan`, `jenis_kendaraan`, `harga`) VALUES
(52, 'Jakarta', 'Badung', 'Pesawat', 700000),
(53, 'Jakarta', 'Badung', 'Bis', 300000),
(54, 'Jakarta', 'Badung', 'Kapal', 400000),
(55, 'Jakarta', 'Denpasar', 'Pesawat', 750000),
(56, 'Jakarta', 'Denpasar', 'Bis', 320000),
(57, 'Jakarta', 'Denpasar', 'Kapal', 450000),
(58, 'Surabaya', 'Badung', 'Pesawat', 600000),
(59, 'Surabaya', 'Badung', 'Bis', 250000),
(60, 'Surabaya', 'Badung', 'Kapal', 350000),
(61, 'Surabaya', 'Denpasar', 'Pesawat', 620000),
(62, 'Surabaya', 'Denpasar', 'Bis', 260000),
(63, 'Surabaya', 'Denpasar', 'Kapal', 360000),
(64, 'Surabaya', 'Gianyar', 'Pesawat', 630000),
(65, 'Surabaya', 'Gianyar', 'Bis', 270000),
(66, 'Surabaya', 'Gianyar', 'Kapal', 370000),
(67, 'Bandung', 'Badung', 'Pesawat', 800000),
(68, 'Bandung', 'Badung', 'Bis', 400000),
(69, 'Bandung', 'Badung', 'Kapal', 500000),
(70, 'Bandung', 'Denpasar', 'Pesawat', 850000),
(71, 'Bandung', 'Denpasar', 'Bis', 420000),
(72, 'Bandung', 'Denpasar', 'Kapal', 520000),
(73, 'Bandung', 'Gianyar', 'Pesawat', 860000),
(74, 'Bandung', 'Gianyar', 'Bis', 430000),
(75, 'Bandung', 'Gianyar', 'Kapal', 530000),
(76, 'Jakarta', 'Karang Asem', 'Pesawat', 780000),
(77, 'Jakarta', 'Karang Asem', 'Bis', 340000),
(78, 'Jakarta', 'Karang Asem', 'Kapal', 470000),
(79, 'Surabaya', 'Karang Asem', 'Pesawat', 650000),
(80, 'Surabaya', 'Karang Asem', 'Bis', 280000),
(81, 'Surabaya', 'Karang Asem', 'Kapal', 380000),
(82, 'Bandung', 'Karang Asem', 'Pesawat', 870000),
(83, 'Bandung', 'Karang Asem', 'Bis', 440000),
(84, 'Bandung', 'Karang Asem', 'Kapal', 540000),
(85, 'Jakarta', 'Buleleng', 'Pesawat', 790000),
(86, 'Jakarta', 'Buleleng', 'Bis', 350000),
(87, 'Jakarta', 'Buleleng', 'Kapal', 480000),
(88, 'Surabaya', 'Buleleng', 'Pesawat', 660000),
(89, 'Surabaya', 'Buleleng', 'Bis', 290000),
(90, 'Surabaya', 'Buleleng', 'Kapal', 390000),
(91, 'Bandung', 'Buleleng', 'Pesawat', 880000),
(92, 'Bandung', 'Buleleng', 'Bis', 450000),
(93, 'Bandung', 'Buleleng', 'Kapal', 550000),
(94, 'Jakarta', 'Jembrana', 'Pesawat', 800000),
(95, 'Jakarta', 'Jembrana', 'Bis', 360000),
(96, 'Jakarta', 'Jembrana', 'Kapal', 490000),
(97, 'Surabaya', 'Jembrana', 'Pesawat', 670000),
(98, 'Surabaya', 'Jembrana', 'Bis', 300000),
(99, 'Surabaya', 'Jembrana', 'Kapal', 400000),
(100, 'Bandung', 'Jembrana', 'Pesawat', 890000),
(101, 'Bandung', 'Jembrana', 'Bis', 460000),
(102, 'Bandung', 'Jembrana', 'Kapal', 560000);

-- --------------------------------------------------------

--
-- Table structure for table `tiket_hotel`
--

CREATE TABLE `tiket_hotel` (
  `id_tiket_hotel` int NOT NULL,
  `tgl_cekin` datetime NOT NULL,
  `tgl_cekout` datetime NOT NULL,
  `total_harga` int NOT NULL,
  `id_user` int NOT NULL,
  `status` enum('0','Batal') COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tiket_hotel`
--

INSERT INTO `tiket_hotel` (`id_tiket_hotel`, `tgl_cekin`, `tgl_cekout`, `total_harga`, `id_user`, `status`) VALUES
(3, '2024-11-13 16:11:54', '2024-11-15 16:11:54', 1790000, 1, '0'),
(5, '2024-11-13 18:16:09', '2024-11-16 18:16:09', 1790000, 1, '0'),
(6, '2024-11-13 18:16:09', '2024-11-17 18:16:00', 1790000, 1, '0'),
(7, '2024-11-13 18:16:09', '2024-11-17 18:16:00', 1790000, 1, '0'),
(8, '2024-11-16 19:30:00', '2024-11-19 19:30:00', 4350000, 1, 'Batal'),
(9, '2024-11-12 19:42:00', '2024-11-19 19:42:00', 3580000, 1, '0'),
(10, '2024-11-14 12:50:24', '2024-11-16 12:50:00', 2600000, 1, '0'),
(11, '2024-12-14 19:27:00', '0524-12-01 19:27:00', 1980000, 3, '0'),
(12, '2024-12-14 19:32:00', '2024-12-15 19:32:00', 460000, 3, 'Batal'),
(13, '2024-11-22 20:14:00', '2024-11-24 20:14:00', 3200000, 3, 'Batal'),
(14, '2024-12-15 04:27:00', '2024-12-16 04:27:00', 490000, 4, 'Batal');

-- --------------------------------------------------------

--
-- Table structure for table `tiket_kendaraan`
--

CREATE TABLE `tiket_kendaraan` (
  `id_tiket_kendaraan` int NOT NULL,
  `id_tarif` int NOT NULL,
  `waktu` datetime NOT NULL,
  `jumlah` int NOT NULL,
  `total_harga` int NOT NULL,
  `id_user` int NOT NULL,
  `status` enum('0','Batal') COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tiket_kendaraan`
--

INSERT INTO `tiket_kendaraan` (`id_tiket_kendaraan`, `id_tarif`, `waktu`, `jumlah`, `total_harga`, `id_user`, `status`) VALUES
(1, 56, '2024-11-13 03:58:48', 2, 640000, 1, '0'),
(4, 52, '2024-11-13 11:59:27', 2, 1400000, 1, '0'),
(5, 52, '2024-11-16 03:58:48', 3, 2100000, 1, 'Batal'),
(6, 78, '2024-11-20 20:14:00', 2, 940000, 3, '0'),
(7, 68, '2024-11-14 21:39:14', 2, 800000, 3, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tiket_wisata`
--

CREATE TABLE `tiket_wisata` (
  `id_tiket_wisata` int NOT NULL,
  `id_wisata` int NOT NULL,
  `waktu` datetime NOT NULL,
  `jumlah_tiket` int NOT NULL,
  `total_harga` int NOT NULL,
  `id_user` int NOT NULL,
  `status` enum('0','Batal') COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tiket_wisata`
--

INSERT INTO `tiket_wisata` (`id_tiket_wisata`, `id_wisata`, `waktu`, `jumlah_tiket`, `total_harga`, `id_user`, `status`) VALUES
(1, 5, '2024-11-13 09:53:41', 2, 120000, 1, '0'),
(2, 2, '2024-11-16 11:59:27', 1, 75000, 1, 'Batal'),
(3, 32, '2024-11-21 20:14:00', 2, 500000, 3, '0'),
(4, 22, '2024-12-15 03:54:00', 2, 140000, 4, 'Batal');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama`, `email`, `password`) VALUES
(1, 'Andi', 'asd', '123'),
(2, 'saya', 'qwe', '123'),
(3, 'Dila Khalisya', 'dilakhalisya@gmail.com', '1234'),
(4, 'Nurin Naizatul Laylisa', 'nurin@gmail.com', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_hotel`
--
ALTER TABLE `data_hotel`
  ADD PRIMARY KEY (`id_hotel`);

--
-- Indexes for table `data_wisata`
--
ALTER TABLE `data_wisata`
  ADD PRIMARY KEY (`id_wisata`);

--
-- Indexes for table `detail_tiket_hotel`
--
ALTER TABLE `detail_tiket_hotel`
  ADD PRIMARY KEY (`id_DTH`),
  ADD KEY `id_tiket_hotel` (`id_tiket_hotel`,`id_hotel`),
  ADD KEY `id_hotel` (`id_hotel`);

--
-- Indexes for table `tarif_rute`
--
ALTER TABLE `tarif_rute`
  ADD PRIMARY KEY (`id_tarif`);

--
-- Indexes for table `tiket_hotel`
--
ALTER TABLE `tiket_hotel`
  ADD PRIMARY KEY (`id_tiket_hotel`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `tiket_kendaraan`
--
ALTER TABLE `tiket_kendaraan`
  ADD PRIMARY KEY (`id_tiket_kendaraan`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_tarif` (`id_tarif`);

--
-- Indexes for table `tiket_wisata`
--
ALTER TABLE `tiket_wisata`
  ADD PRIMARY KEY (`id_tiket_wisata`),
  ADD KEY `id_wisata` (`id_wisata`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_hotel`
--
ALTER TABLE `data_hotel`
  MODIFY `id_hotel` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `data_wisata`
--
ALTER TABLE `data_wisata`
  MODIFY `id_wisata` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `detail_tiket_hotel`
--
ALTER TABLE `detail_tiket_hotel`
  MODIFY `id_DTH` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tarif_rute`
--
ALTER TABLE `tarif_rute`
  MODIFY `id_tarif` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `tiket_hotel`
--
ALTER TABLE `tiket_hotel`
  MODIFY `id_tiket_hotel` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tiket_kendaraan`
--
ALTER TABLE `tiket_kendaraan`
  MODIFY `id_tiket_kendaraan` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tiket_wisata`
--
ALTER TABLE `tiket_wisata`
  MODIFY `id_tiket_wisata` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `detail_tiket_hotel`
--
ALTER TABLE `detail_tiket_hotel`
  ADD CONSTRAINT `detail_tiket_hotel_ibfk_1` FOREIGN KEY (`id_tiket_hotel`) REFERENCES `tiket_hotel` (`id_tiket_hotel`),
  ADD CONSTRAINT `detail_tiket_hotel_ibfk_2` FOREIGN KEY (`id_hotel`) REFERENCES `data_hotel` (`id_hotel`);

--
-- Constraints for table `tiket_hotel`
--
ALTER TABLE `tiket_hotel`
  ADD CONSTRAINT `tiket_hotel_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`);

--
-- Constraints for table `tiket_kendaraan`
--
ALTER TABLE `tiket_kendaraan`
  ADD CONSTRAINT `tiket_kendaraan_ibfk_1` FOREIGN KEY (`id_tarif`) REFERENCES `tarif_rute` (`id_tarif`),
  ADD CONSTRAINT `tiket_kendaraan_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`);

--
-- Constraints for table `tiket_wisata`
--
ALTER TABLE `tiket_wisata`
  ADD CONSTRAINT `tiket_wisata_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`),
  ADD CONSTRAINT `tiket_wisata_ibfk_2` FOREIGN KEY (`id_wisata`) REFERENCES `data_wisata` (`id_wisata`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
