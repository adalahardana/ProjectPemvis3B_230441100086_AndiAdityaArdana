
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
public class Tarif_Rute {
    private int id_tarif;
    private String tempat_asal;
    private String tempat_tujuan;
    private String jenis_kendaraan;
    private int harga;
    
    public Tarif_Rute(int id_tarif, String tempat_asal, String tempat_tujuan, String jenis_kendaraan, int harga) {
        this.id_tarif = id_tarif;
        this.tempat_asal = tempat_asal;
        this.tempat_tujuan = tempat_tujuan;
        this.jenis_kendaraan = jenis_kendaraan;
        this.harga = harga;
    }

    public static Tarif_Rute getHargaTiket(String tempat_asal, String tempat_tujuan, String jenis_kendaraan) {
        Tarif_Rute tarif_rute = null;
        String query = "SELECT * FROM tarif_rute WHERE tempat_asal = ? AND tempat_tujuan = ? AND jenis_kendaraan = ?";
        
        try (Connection connection = koneksi.getConnection();
            PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, tempat_asal);
            ps.setString(2, tempat_tujuan);
            ps.setString(3, jenis_kendaraan);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                tarif_rute = new Tarif_Rute(
                    rs.getInt("id_tarif"),
                    rs.getString("tempat_asal"),
                    rs.getString("tempat_tujuan"),
                    rs.getString("jenis_kendaraan"),
                    rs.getInt("harga")
                );
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return tarif_rute;
    }
    public static Tarif_Rute getById(int id_tarif) {
        Tarif_Rute tarif_rute = null;
        String query = "SELECT * FROM tarif_rute WHERE id_tarif = ?";
        
        try (Connection connection = koneksi.getConnection();
            PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id_tarif);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                tarif_rute = new Tarif_Rute(
                    rs.getInt("id_tarif"),
                    rs.getString("tempat_asal"),
                    rs.getString("tempat_tujuan"),
                    rs.getString("jenis_kendaraan"),
                    rs.getInt("harga")
                );
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return tarif_rute;
    }
    
    public int getId_tarif() {
        return id_tarif;
    }
    public String getTempat_asal() {
        return tempat_asal;
    }
    public String getTempat_tujuan() {
        return tempat_tujuan;
    }
    public String getJenis_kendaraan() {
        return jenis_kendaraan;
    }
    public int getHarga() {
        return harga;
    }

    public void setId_tarif(int id_tarif) {
        this.id_tarif = id_tarif;
    }
    public void setTempat_asal(String tempat_asal) {
        this.tempat_asal = tempat_asal;
    }
    public void setTempat_tujuan(String tempat_tujuan) {
        this.tempat_tujuan = tempat_tujuan;
    }
    public void setJenis_kendaraan(String jenis_kendaraan) {
        this.jenis_kendaraan = jenis_kendaraan;
    }
    public void setHarga(int harga) {
        this.harga = harga;
    }
    
}
