
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HP
 */
public class Data_Wisata {
    private int id_wisata;
    private String nama_wisata;
    private String kota;
    private int harga;
    
    public Data_Wisata(int id_wisata, String nama_wisata, String kota, int harga) {
        this.id_wisata = id_wisata;
        this.nama_wisata = nama_wisata;
        this.kota = kota;
        this.harga = harga;
    }

    public static Data_Wisata getById(int id_wisata) {
        Data_Wisata data = null;
        String query = "SELECT * FROM data_wisata WHERE id_wisata = ?";
        
        try (Connection connection = koneksi.getConnection();
            PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, id_wisata);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                data = new Data_Wisata(
                    rs.getInt("id_wisata"),
                    rs.getString("nama_wisata"),
                    rs.getString("kota"),
                    rs.getInt("harga")
                );
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return data;
    }
    public static List<Data_Wisata> getWisataByKota(String kota) {
        List<Data_Wisata> data_wisata_list = new ArrayList<>();
        String query = "SELECT * FROM data_wisata WHERE kota = ?";
        
        try (Connection connection = koneksi.getConnection();
            PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, kota);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                data_wisata_list.add(new Data_Wisata(
                    rs.getInt("id_wisata"),
                    rs.getString("nama_wisata"),
                    rs.getString("kota"),
                    rs.getInt("harga")
                ));
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return data_wisata_list;
    }
    public static Data_Wisata getHargaTiket(String nama_wisata) {
        Data_Wisata data_wisata = null;
        String query = "SELECT * FROM data_wisata WHERE nama_wisata = ?";
        
        try (Connection connection = koneksi.getConnection();
            PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, nama_wisata);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                data_wisata = new Data_Wisata(
                    rs.getInt("id_wisata"),
                    rs.getString("nama_wisata"),
                    rs.getString("kota"),
                    rs.getInt("harga")
                );
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return data_wisata;
    }

    public int getId_wisata() {
        return id_wisata;
    }
    public String getNama_wisata() {
        return nama_wisata;
    }
    public String getKota() {
        return kota;
    }
    public int getHarga() {
        return harga;
    }

    public void setId_wisata(int id_wisata) {
        this.id_wisata = id_wisata;
    }
    public void setNama_wisata(String nama_wisata) {
        this.nama_wisata = nama_wisata;
    }
    public void setKota(String kota) {
        this.kota = kota;
    }
    public void setHarga(int harga) {
        this.harga = harga;
    }
}
